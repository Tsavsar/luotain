'use client'

import { useEffect, useState } from 'react'
import { useMockDataState } from '@/components/mockdatacontext'
import { useRouter } from 'next/navigation'
import LinksStats from '@/components/linksstats'
import LinksTable from '@/components/linkstable'
import RecentlyDeletedLink from '@/components/recentlydeletedlink'
import { slugOf } from '@/components/linktablehelpers'
import { toast } from '@/components/toast'
import {
  getMockLinksStats,
  getMockLinksTable,
  getMockTrash,
} from '@/lib/mockAnalytics'

export default function LinksPage() {
  const router = useRouter()
  // Shared across every page and persisted, so switching it on once
  // sticks instead of resetting on each navigation.
  const {
    useMockData,
    ready: mockReady,
    deletedUrls,
    deleteMockLink,
    recoverMockLink,
  } = useMockDataState()
  const [selectedRange, setSelectedRange] = useState('Last 7 days')

  // deletedUrls is passed through so the totals drop when something is
  // deleted — no link, nothing to report.
  const stats = useMockData
    ? getMockLinksStats(selectedRange, [], deletedUrls)
    : null

  // Real state, re-seeded from the generator only when the inputs
  // that should reset it change (mock toggled, range changed), so a
  // delete's own removal otherwise sticks.
  const [links, setLinks] = useState(null)
  useEffect(() => {
    // Wait until the saved mock preference is known — otherwise a
    // reload with mock on hits the network once for nothing.
    if (!mockReady) return
    let cancelled = false

    if (useMockData) {
      setLinks(getMockLinksTable(selectedRange, [], deletedUrls))
      return
    }

    // Real path. `null` while in flight rather than [] — the table
    // treats null as "not loaded" and [] as "genuinely no links", so
    // this doesn't flash the empty state before rows arrive.
    setLinks(null)
    fetch('/api/links')
      .then((res) => {
        if (!res.ok) throw new Error(`links list failed: ${res.status}`)
        return res.json()
      })
      .then((data) => {
        if (!cancelled) setLinks(data.links ?? [])
      })
      .catch((err) => {
        console.error('[LinksPage]', err)
        if (!cancelled) setLinks([])
      })

    return () => {
      cancelled = true
    }
  }, [mockReady, useMockData, selectedRange, deletedUrls])

  async function handleDelete(link) {
    // Mock rows are display-only — their id is the link's own url
    // string (e.g. "luot.link/summer-sale"), which isn't a real cuid AND
    // contains a slash, so it can't even go in a URL path: a fetch to
    // /api/links/luot.link/summer-sale/delete doesn't resolve to the
    // [id] route at all, it just hangs. So while mock data is on,
    // this stays fully local: no fetch regardless.
    if (useMockData) {
      // Recorded in shared state rather than filtered out of this
      // page's list. The row disappearing is only part of a delete —
      // it also has to join the trash, leave the totals, and switch
      // its own detail page to the archived state. The effect above
      // re-seeds from the same source, so the row goes on its own.
      deleteMockLink(link.shortUrl)
      toast(`${link.shortUrl} moved to trash`, {
        action: {
          label: 'Undo',
          onClick: () => recoverMockLink(link.shortUrl),
        },
      })
      return
    }

    // Real path — link.id here is a real cuid with no slashes.
    const res = await fetch(`/api/links/${link.id}/delete`, {
      method: 'POST',
    })
    if (!res.ok) {
      // Thrown, not caught here — DeleteConfirmModal's own handleConfirm
      // wraps this call in a try/catch that re-enables its button and
      // keeps the modal open on failure. Catching it here would just
      // swallow that.
      throw new Error('Failed to delete link')
    }
    setLinks((prev) => (prev || []).filter((l) => l.id !== link.id))
    toast(`${link.shortUrl} moved to trash`, {
      action: {
        label: 'Undo',
        onClick: async () => {
          // Same endpoint the trash page's Recover uses — undo IS a
          // recover, just triggered from the toast instead of the
          // trash list.
          const recoverRes = await fetch(`/api/links/${link.id}/recover`, {
            method: 'POST',
          })
          if (recoverRes.ok) {
            setLinks((prev) => {
              const list = prev || []
              return list.some((l) => l.id === link.id) ? list : [link, ...list]
            })
          } else {
            toast.error(`Couldn't undo`)
          }
        },
      },
    })
  }

  return (
    <>
      <div
        className='dashboard-section dashboard-section-3 dashboard-page-padding'
        style={{
          width: '100%',
          display: 'flex',
          justifyContent: 'center',
          paddingTop: 0,
          paddingBottom: 0,
        }}
      >
        <LinksStats
          stats={stats}
          selectedRange={selectedRange}
          onRangeChange={setSelectedRange}
        />
      </div>

      <div
        className='dashboard-section dashboard-section-4 dashboard-page-padding'
        style={{
          width: '100%',
          display: 'flex',
          justifyContent: 'center',
          paddingTop: '32px',
          paddingBottom: '24px',
        }}
      >
        {/* No mock toggle on, table renders its own empty state —
            same "no data yet" the real app shows before any links
            have been created, not a separate loading state. */}
        <LinksTable
          links={links}
          onOpen={(link) =>
            router.push(`/dashboard/links/${slugOf(link.shortUrl)}`)
          }
          onEdit={(link) => {
            // TODO: route to the link's edit view once it exists
          }}
          onDuplicate={(link) => {
            // Blocked on the create flow, not stubbed out of laziness:
            // duplicating means creating a new link with this one's
            // destination and a fresh slug, and there's no POST /api/links
            // yet to create anything with. Wire this to the create form
            // pre-filled from `link` once that exists.
            toast('Duplicating needs the create flow first')
          }}
          onDelete={handleDelete}
        />
      </div>

      {/* Its own section at the foot of the page rather than tucked
          under the table. marginTop:auto is what pushes it down: the
          layout's <main> is a flex column at min-height 100vh, so the
          spare vertical space collects above this instead of below it.
          On a long list it simply follows the table; on a short one it
          settles at the bottom of the screen.

          The component returns null when the trash is empty, so this
          whole row collapses to nothing — no reserved height, no
          stranded gap at the bottom of the page. */}
      <div
        className='dashboard-section dashboard-section-5 dashboard-page-padding'
        style={{
          width: '100%',
          display: 'flex',
          justifyContent: 'center',
          marginTop: 'auto',
          paddingTop: '24px',
          paddingBottom: '40px',
        }}
      >
        <div
          style={{
            width: '100%',
            maxWidth: '720px',
            display: 'flex',
            justifyContent: 'flex-end',
          }}
        >
          <RecentlyDeletedLink
            count={useMockData ? getMockTrash(deletedUrls).length : undefined}
          />
        </div>
      </div>
    </>
  )
}
